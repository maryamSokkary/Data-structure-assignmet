#include "Matrix.h"

using namespace std;

int main() {



	Matrix  matrix1 (4,5);
	Matrix matrix2 (4,5);
	Matrix matrix3 (4,5);
	Matrix matrix4 (4,5);

	for (int i = 0; i < 4; i++)
		for (int j = 0; j < 5; j++)
			matrix1.setNumber(i,j,2);


	for (int i = 0; i < 4; i++)
			for (int j = 0; j < 5; j++)
				matrix2.setNumber(i,j,3);


	for (int i = 0; i < 4; i++)
		for (int j = 0; j < 5; j++)
			matrix3.setNumber(i,j,i+1);

	cout << "Matrix 1" << endl;
	cout << matrix1 << endl;

	cout << "Matrix 2" << endl;
	cout << matrix2 << endl;

	cout << "Matrix 3 "<< endl;
	cout << matrix3 << endl;

	cout << "Matrix 3 after transposing" << endl;
	matrix3.transpose();
	cout << matrix3 << endl;

	cout << "Matrix 4 = Matrix 1 + Matrix 2" << endl;
	matrix4 = matrix1 + matrix2;
	cout << matrix4 << endl;

	cout << "Matrix 4 = Matrix 2 - Matrix 1" << endl;
	matrix4 = matrix2 - matrix1;
	cout << matrix4 << endl;

	cout << "Matrix 4 = Matrix 2 * Matrix 1" << endl;
	matrix4 = matrix2 * matrix1;
	cout << matrix4 << endl;

}
