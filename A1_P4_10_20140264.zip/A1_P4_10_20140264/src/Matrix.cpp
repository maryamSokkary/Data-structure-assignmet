
#include "Matrix.h"

using namespace std;

Matrix ::Matrix() {

	n = 0;
	m = 0;
	matrix = NULL;
}

Matrix ::Matrix (int n, int m){
	this->n = n;
	this->m = m;
	matrix = new int* [n];
	for (int i = 0; i < n; i++)
		matrix[i] = new int [m];

}


void Matrix ::setNumber(int x, int y, int num){
	matrix [x][y] = num;
}


int Matrix ::getNumber(int x, int y){
	return matrix [x][y];
}


void Matrix ::setRow(int n){
	this->n= n;
}


void Matrix ::setCol(int m){
	this->m = m;
}


int Matrix ::getRow(){
	return n;
}


int Matrix ::getCol(){
	return m;
}


Matrix  operator+(const Matrix  &matrix1, const Matrix  &matrix2){

	int x = matrix1.n;
	int y = matrix1.m;

	Matrix  result (x, y);

	for (int i = 0; i < x; i++)
		for (int j = 0; j < y; j++)
			result.matrix[i][j] = matrix1.matrix[i][j] + matrix2.matrix[i][j];

	return result;
}


Matrix  operator* (const Matrix & matrix1, const Matrix  &matrix2){

	int x = matrix1.n;
	int y = matrix1.m;

	Matrix  result (x, y);

	for (int i = 0; i < x; i++)
		for (int j = 0; j < y; j++)
			result.matrix[i][j] = matrix1.matrix[i][j] * matrix2.matrix[i][j];

	return result;
}


Matrix  operator- (const Matrix & matrix1, const Matrix  &matrix2){

	int x = matrix1.n;
	int y = matrix1.m;

	Matrix  result (x, y);

	for (int i = 0; i < x; i++)
		for (int j = 0; j < y; j++)
			result.matrix[i][j] = matrix1.matrix[i][j] - matrix2.matrix[i][j];

	return result;
}


ostream& operator<< (ostream& out, const Matrix & tobePrinted){

	for (int i = 0; i < tobePrinted.n; i++){
		for (int j = 0; j < tobePrinted.m; j++)
			out << tobePrinted.matrix[i][j] << ' ';
		out << endl;
	}

	return out;

}


void Matrix ::transpose(){

	int **newMatrix = new int* [m];

	for (int i = 0; i < m; i++)
		newMatrix[i] = new int [n];

	for (int i = 0; i < n; i++)
		for (int j = 0; j < m; j++)
			newMatrix[j][i] = matrix[i][j];

	for (int i = 0; i < n; i++)
			delete [] matrix[i];
		delete [] matrix;

	swap (n,m);

	matrix = new int* [n];
	for (int i = 0; i < n; i++)
			matrix[i] = new int [m];

	for (int i = 0; i < n; i++)
		for (int j = 0; j < m; j++)
			matrix[i][j] = newMatrix[i][j];

	for (int i = 0; i < n; i++)
			delete [] newMatrix[i];
		delete [] newMatrix;
}


void Matrix ::operator =(const Matrix &LHS){
	n = LHS.n;
	m = LHS.m;

	for (int i = 0; i < n; i++)
		for (int j = 0; j < m; j++)
			matrix[i][j] = LHS.matrix[i][j];


}


Matrix ::~Matrix() {
	for (int i = 0; i < n; i++)
		delete [] matrix[i];
	delete [] matrix;
}
