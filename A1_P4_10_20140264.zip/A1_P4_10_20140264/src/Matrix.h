#ifndef MATRIX_H_
#define MATRIX_H_

#include <bits/stdc++.h>

using namespace std;

class Matrix {
private:
	int n;
	int m;
	int **matrix;

public:
	Matrix();
	Matrix(int , int );
	void operator= (const Matrix &);
	friend Matrix operator+ (const Matrix &, const Matrix &);
	friend Matrix operator* (const Matrix &, const Matrix &);
	friend Matrix operator- (const Matrix &, const Matrix &);
	friend ostream&  operator<< (ostream &, const Matrix &);
	void setNumber (int, int, int);
	void setRow (int);
	void setCol (int);
	int getRow ();
	int getCol ();
	int getNumber (int, int);
	void transpose ();
	virtual ~Matrix();
};

#endif /* MATRIX_H_ */
